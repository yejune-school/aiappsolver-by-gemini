package com.example.aipuzzlesolver.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.aipuzzlesolver.data.AppPreferences

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefs: AppPreferences,
    onBackClick: () -> Unit
) {
    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    var interval by remember { mutableStateOf(prefs.captureIntervalSeconds.toString()) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("설정") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("Gemini API Key") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = interval,
                onValueChange = { interval = it },
                label = { Text("캡처 간격 (초)") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    prefs.apiKey = apiKey
                    prefs.captureIntervalSeconds = interval.toIntOrNull() ?: 2
                    onBackClick()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("저장")
            }
        }
    }
}
