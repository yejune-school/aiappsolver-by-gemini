package com.example.aipuzzlesolver.data

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("solver_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("gemini_api_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_api_key", value).apply()

    var captureIntervalSeconds: Int
        get() = prefs.getInt("capture_interval", 2)
        set(value) = prefs.edit().putInt("capture_interval", value).apply()

    var autoAnalyze: Boolean
        get() = prefs.getBoolean("auto_analyze", true)
        set(value) = prefs.edit().putBoolean("auto_analyze", value).apply()

    var selectedModel: String
        get() = prefs.getString("selected_model", "gemini-1.5-flash") ?: "gemini-1.5-flash"
        set(value) = prefs.edit().putString("selected_model", value).apply()
}
