package com.example.aipuzzlesolver

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import com.example.aipuzzlesolver.data.AppPreferences
import com.example.aipuzzlesolver.service.CaptureService
import com.example.aipuzzlesolver.service.OverlayService
import com.example.aipuzzlesolver.ui.MainScreen
import com.example.aipuzzlesolver.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    private lateinit var prefs: AppPreferences

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val intent = Intent(this, CaptureService::class.java)
            startForegroundService(intent)
            startService(Intent(this, OverlayService::class.java))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate()
        prefs = AppPreferences(this)

        checkOverlayPermission()

        setContent {
            var currentScreen by remember { mutableStateOf("main") }

            if (currentScreen == "main") {
                MainScreen(
                    prefs = prefs,
                    onStartCaptureClick = { requestScreenCapture() },
                    onOpenSettingsClick = { currentScreen = "settings" }
                )
            } else {
                SettingsScreen(
                    prefs = prefs,
                    onBackClick = { currentScreen = "main" }
                )
            }
        }
    }

    private fun checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun requestScreenCapture() {
        val mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        captureLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
    }
}
