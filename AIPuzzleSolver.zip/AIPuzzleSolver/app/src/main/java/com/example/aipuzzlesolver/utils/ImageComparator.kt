package com.example.aipuzzlesolver.utils

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

object ImageComparator {
    fun isSignificantChange(oldBitmap: Bitmap?, newBitmap: Bitmap, thresholdPercent: Double = 3.0): Boolean {
        if (oldBitmap == null) return true
        if (oldBitmap.width != newBitmap.width || oldBitmap.height != newBitmap.height) return true

        val width = 100
        val height = 100

        val scaledOld = Bitmap.createScaledBitmap(oldBitmap, width, height, false)
        val scaledNew = Bitmap.createScaledBitmap(newBitmap, width, height, false)

        var diffPixels = 0
        val totalPixels = width * height

        for (x in 0 until width) {
            for (y in 0 until height) {
                val p1 = scaledOld.getPixel(x, y)
                val p2 = scaledNew.getPixel(x, y)

                val diffR = abs(Color.red(p1) - Color.red(p2))
                val diffG = abs(Color.green(p1) - Color.green(p2))
                val diffB = abs(Color.blue(p1) - Color.blue(p2))

                if (diffR + diffG + diffB > 100) {
                    diffPixels++
                }
            }
        }

        val changeRate = (diffPixels.toDouble() / totalPixels) * 100.0
        return changeRate >= thresholdPercent
    }
}
