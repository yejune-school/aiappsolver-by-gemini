package com.example.aipuzzlesolver.service

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.example.aipuzzlesolver.data.AppPreferences
import com.example.aipuzzlesolver.data.GeminiRepository
import com.example.aipuzzlesolver.utils.ImageComparator
import kotlinx.coroutines.*

class CaptureService : Service() {

    private val binder = LocalBinder()
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var captureJob: Job? = null

    private var previousBitmap: Bitmap? = null
    private var isProcessing = false

    inner class LocalBinder : Binder() {
        fun getService(): CaptureService = this@CaptureService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        startForegroundService()
    }

    private fun startForegroundService() {
        val channelId = "capture_channel"
        val channelName = "Screen Capture Service"
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_LOW)
        notificationManager.createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("AI 실시간 문제 분석 중")
            .setContentText("화면의 문제를 감지하고 있습니다.")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()

        startForeground(1001, notification)
    }

    fun startCapture(resultCode: Int, data: Intent) {
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ScreenCapture",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        startPeriodicAnalysis(width, height)
    }

    private fun startPeriodicAnalysis(width: Int, height: Int) {
        val prefs = AppPreferences(this)
        val repository = GeminiRepository(prefs)

        captureJob = scope.launch {
            while (isActive) {
                delay(prefs.captureIntervalSeconds * 1000L)

                if (!prefs.autoAnalyze || isProcessing) continue

                val bitmap = captureFrame(width, height) ?: continue

                if (ImageComparator.isSignificantChange(previousBitmap, bitmap)) {
                    previousBitmap = bitmap
                    isProcessing = true

                    val result = repository.analyzeImage(bitmap)
                    result.onSuccess { response ->
                        OverlayService.updateResults(this@CaptureService, response.problems)
                    }

                    isProcessing = false
                }
            }
        }
    }

    private fun captureFrame(width: Int, height: Int): Bitmap? {
        val image = imageReader?.acquireLatestImage() ?: return null
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * width

        val bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
        bitmap.copyPixelsFromBuffer(buffer)
        image.close()

        return Bitmap.createBitmap(bitmap, 0, 0, width, height)
    }

    fun stopCapture() {
        captureJob?.cancel()
        virtualDisplay?.release()
        mediaProjection?.stop()
        stopSelf()
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
