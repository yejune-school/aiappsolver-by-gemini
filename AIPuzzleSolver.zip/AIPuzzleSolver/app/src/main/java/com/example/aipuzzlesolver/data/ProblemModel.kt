package com.example.aipuzzlesolver.data

import kotlinx.serialization.Serializable

@Serializable
data class BoundingBox(
    val left: Int = 0,
    val top: Int = 0,
    val right: Int = 0,
    val bottom: Int = 0
)

@Serializable
data class ProblemItem(
    val id: String = "",
    val number: String = "",
    val question: String = "",
    val answer: String = "",
    val solution: String = "",
    val confidence: Float = 0.0f,
    val boundingBox: BoundingBox = BoundingBox()
)

@Serializable
data class GeminiResponse(
    val problems: List<ProblemItem> = emptyList()
)
