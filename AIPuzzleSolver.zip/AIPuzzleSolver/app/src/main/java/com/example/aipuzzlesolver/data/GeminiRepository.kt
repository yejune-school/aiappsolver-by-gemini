package com.example.aipuzzlesolver.data

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiRepository(private val prefs: AppPreferences) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun analyzeImage(bitmap: Bitmap): Result<GeminiResponse> = withContext(Dispatchers.IO) {
        val apiKey = prefs.apiKey
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("API Key가 설정되지 않았습니다."))
        }

        val base64Image = bitmap.toBase64()
        val model = prefs.selectedModel
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val prompt = """
            제공된 이미지에서 모든 학습/수학 문제를 탐지하세요.
            응답은 반드시 아래 JSON 구조로만 답변하고 설명이나 마크다운 백틱을 추가하지 마세요.
            
            {
              "problems": [
                {
                  "id": "유니크ID",
                  "number": "문제번호",
                  "question": "문제 내용",
                  "answer": "최종 답",
                  "solution": "짧은 풀이 과정",
                  "confidence": 0.95,
                  "boundingBox": { "left": X1, "top": Y1, "right": X2, "bottom": Y2 }
                }
              ]
            }
        """.trimIndent()

        val requestJson = """
            {
              "contents": [{
                "parts": [
                  {"text": ${Json.encodeToString(kotlinx.serialization.serializer(), prompt)}},
                  {
                    "inline_data": {
                      "mime_type": "image/jpeg",
                      "data": "$base64Image"
                    }
                  }
                ]
              }]
            }
        """.trimIndent()

        try {
            val request = Request.Builder()
                .url(url)
                .post(requestJson.toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("HTTP 오류: ${response.code}"))
                }

                val bodyStr = response.body?.string() ?: ""
                val cleanJson = extractJsonText(bodyStr)
                val result = json.decodeFromString<GeminiResponse>(cleanJson)
                Result.success(result)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun Bitmap.toBase64(): String {
        val stream = ByteArrayOutputStream()
        this.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    private fun extractJsonText(responseBody: String): String {
        val candidateMarker = "\"text\": \""
        val startIndex = responseBody.indexOf(candidateMarker)
        if (startIndex == -1) return "{\"problems\":[]}"
        
        val rawText = responseBody.substring(startIndex + candidateMarker.length)
            .replace("\\n", "")
            .replace("\\\"", "\"")
            
        val jsonStart = rawText.indexOf("{")
        val jsonEnd = rawText.lastIndexOf("}")
        return if (jsonStart != -1 && jsonEnd != -1) rawText.substring(jsonStart, jsonEnd + 1) else "{\"problems\":[]}"
    }
}
