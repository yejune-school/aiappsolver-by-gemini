package com.example.aipuzzlesolver.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.aipuzzlesolver.data.ProblemItem

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private val activeViews = mutableListOf<View>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        instance = this
    }

    fun renderProblems(problems: List<ProblemItem>) {
        clearOverlays()

        for (problem in problems) {
            val view = createOverlayCard(problem)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = problem.boundingBox.left.coerceAtLeast(50)
                y = problem.boundingBox.top.coerceAtLeast(100)
            }

            attachDragToView(view, params)
            windowManager.addView(view, params)
            activeViews.add(view)
        }
    }

    private fun createOverlayCard(problem: ProblemItem): View {
        val context = this
        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#CC000000"))
            setPadding(24, 16, 24, 16)
        }

        val tvTitle = TextView(context).apply {
            text = "문제 ${problem.number} | 답: ${problem.answer}"
            setTextColor(Color.GREEN)
            textSize = 14f
        }

        val tvSolution = TextView(context).apply {
            text = problem.solution
            setTextColor(Color.WHITE)
            textSize = 12f
            visibility = View.GONE
        }

        val btnToggle = Button(context).apply {
            text = "풀이 보기"
            textSize = 10f
            setOnClickListener {
                if (tvSolution.visibility == View.GONE) {
                    tvSolution.visibility = View.VISIBLE
                    text = "접기"
                } else {
                    tvSolution.visibility = View.GONE
                    text = "풀이 보기"
                }
            }
        }

        layout.addView(tvTitle)
        layout.addView(tvSolution)
        layout.addView(btnToggle)

        return layout
    }

    private fun attachDragToView(view: View, params: WindowManager.LayoutParams) {
        view.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(view, params)
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun clearOverlays() {
        for (view in activeViews) {
            windowManager.removeView(view)
        }
        activeViews.clear()
    }

    override fun onDestroy() {
        clearOverlays()
        super.onDestroy()
    }

    companion object {
        private var instance: OverlayService? = null

        fun updateResults(context: Context, problems: List<ProblemItem>) {
            instance?.renderProblems(problems)
        }
    }
}
