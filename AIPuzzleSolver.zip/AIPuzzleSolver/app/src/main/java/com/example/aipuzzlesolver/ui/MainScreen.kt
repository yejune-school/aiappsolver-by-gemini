package com.example.aipuzzlesolver.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.aipuzzlesolver.data.AppPreferences

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    prefs: AppPreferences,
    onStartCaptureClick: () -> Unit,
    onOpenSettingsClick: () -> Unit
) {
    var isAutoAnalyze by remember { mutableStateOf(prefs.autoAnalyze) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("AI 실시간 문제 풀이") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("상태: 서비스 준비 완료", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("설정된 분석 간격: ${prefs.captureIntervalSeconds}초")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("자동 분석 활성화")
                Switch(
                    checked = isAutoAnalyze,
                    onCheckedChange = {
                        isAutoAnalyze = it
                        prefs.autoAnalyze = it
                    }
                )
            }

            Button(
                onClick = onStartCaptureClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("화면 캡처 및 AI 분석 시작")
            }

            OutlinedButton(
                onClick = onOpenSettingsClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("API Key 및 설정")
            }
        }
    }
}
